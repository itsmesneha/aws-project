# Cloud Net Final Project
Hopefully you had a great time and are now capable of applying what you learnt and deploy your own site as your final project.

## Steps
- Clone this repository.
- Replace [img.jpeg](img.jpeg) file with you picture and name it as `img.jpeg`
- Replace the links for your Github id's and LinkedIn id's
- Add your roles and assignments
- Write something great about you and let the world get a sneak peak into the person that you are